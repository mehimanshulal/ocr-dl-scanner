// import { Jimp } from 'jimp';
// import { Component } from '@angular/core';
// import * as Tesseract from 'tesseract.js';

// // @Component({
// //   selector: 'app-ocr-reader-form',
// //   templateUrl: './ocr-reader-form.component.html',
// //   styleUrls: ['./ocr-reader-form.component.css'],
// // })

// @Component({
//   selector: 'app-ocr-reader-form',
//   standalone: true,
//   templateUrl: './ocr-reader-form.component.html',
//   styleUrls: ['./ocr-reader-form.component.css'],
// })
// export class OcrReaderFormComponent {
//   selectedFile: File | null = null;
//   ocrResult: string = '';
//   loading: boolean = false;

//   onFileSelected(event: Event): void {
//     const input = event.target as HTMLInputElement;
//     if (input.files && input.files.length) {
//       this.selectedFile = input.files[0];
//     }
//   }

//   onSubmit(): void {
//     if (this.selectedFile) {
//       this.loading = true;
//       this.ocrResult = '';

//       // Jimp.read()

//       Tesseract.recognize(this.selectedFile, 'eng', {
//         logger: (m) => console.log(m),
//       })
//         .then(({ data: { text } }) => {
//           this.ocrResult = text;
//         })
//         .finally(() => {
//           this.loading = false;
//         })
//         .catch((err) => {
//           console.error('Error recognizing text:', err);
//           this.ocrResult = 'Error recognizing text.';
//           this.loading = false;
//         });
//     }
//   }
// }
// import { Component } from '@angular/core';
// import {
//   PDF417Reader,
//   DecodeHintType,
//   BarcodeFormat,
//   BinaryBitmap,
//   HybridBinarizer,
//   RGBLuminanceSource,
//   Result,
// } from '@zxing/library';
// // import * as Jimp from 'jimp';
// // import Jimp from 'jimp'
// import { Jimp } from 'jimp';
// import { Buffer } from 'buffer';

// @Component({
//   selector: 'app-ocr-reader-form',
//   standalone: true,
//   templateUrl: './ocr-reader-form.component.html',
//   styleUrls: ['./ocr-reader-form.component.css'],
// })
// export class OcrReaderFormComponent {
//   public async onFileSelected(event: Event): Promise<void> {
//     const input = event.target as HTMLInputElement;
//     if (input?.files?.length) {
//       const file: File = input.files[0];
//       const arrayBuffer: ArrayBuffer = await file.arrayBuffer();

//       // Convert ArrayBuffer to Buffer (Node.js Buffer)
//       const buffer = Buffer.from(arrayBuffer);

//       Jimp.read(buffer)
//         .then(
//           (
//             image: ReturnType<typeof Jimp.read> extends Promise<infer I>
//               ? I
//               : never
//           ) => {
//             const width: number = image.bitmap.width;
//             const height: number = image.bitmap.height;
//             const int32Array: Int32Array = new Int32Array(
//               image.bitmap.data.buffer
//             );

//             const luminanceSource: RGBLuminanceSource = new RGBLuminanceSource(
//               int32Array,
//               width,
//               height
//             );
//             const binaryBitmap: BinaryBitmap = new BinaryBitmap(
//               new HybridBinarizer(luminanceSource)
//             );

//             const hints: Map<DecodeHintType, BarcodeFormat[]> = new Map();
//             const formats: BarcodeFormat[] = [BarcodeFormat.PDF_417];
//             hints.set(DecodeHintType.POSSIBLE_FORMATS, formats);

//             const reader: PDF417Reader = new PDF417Reader();
//             const result: Result = reader.decode(binaryBitmap, hints);

//             // Use the getText() method to safely retrieve the decoded text
//             this.parseAAMVA(result.getText());
//           }
//         )
//         .catch((error: Error) => {
//           console.error('Error reading image:', error);
//         });
//     }
//   }

//   private parseAAMVA(data: string): void {
//     const regexName = /DAC([^\n]*)/;
//     const regexDOB = /DBB(\d{8})/;
//     const regexLicenseNumber = /DAQ([^\n]*)/;

//     const nameMatch: RegExpMatchArray | null = data.match(regexName);
//     const dobMatch: RegExpMatchArray | null = data.match(regexDOB);
//     const licenseNumberMatch: RegExpMatchArray | null =
//       data.match(regexLicenseNumber);

//     const name: string = nameMatch ? nameMatch[1].trim() : 'Not found';
//     const dob: string = dobMatch ? dobMatch[1] : 'Not found';
//     const licenseNumber: string = licenseNumberMatch
//       ? licenseNumberMatch[1].trim()
//       : 'Not found';

//     console.log('Name:', name);
//     console.log('Date of Birth:', dob);
//     console.log('License Number:', licenseNumber);
//   }
// }

// src/app/ocr-reader-form/ocr-reader-form.component.ts

import { Component } from '@angular/core';
import { Jimp } from 'jimp';
import { Buffer } from 'buffer';

@Component({
  selector: 'app-ocr-reader-form',
  standalone: true,
  imports: [],
  templateUrl: './ocr-reader-form.component.html',
  styleUrls: ['./ocr-reader-form.component.css'],
})
export class OcrReaderFormComponent {
  selectedFile: File | null = null;
  ocrResult: string = '';
  loading: boolean = false;

  public async onFileSelected(event: Event): Promise<void> {
    console.log('onFileSelected called,', event);
    const input = event.target as HTMLInputElement;
    if (input?.files?.length) {
      const file: File = input.files[0];
      const arrayBuffer: ArrayBuffer = await file.arrayBuffer();

      const buffer = Buffer.from(arrayBuffer);

      this.loading = true;
      Jimp.read(buffer)
        .then((image) => {
          const width = image.bitmap.width;
          const height = image.bitmap.height;
          const int32Array = new Int32Array(image.bitmap.data.buffer);

          // Here, implement image processing or decoding as per your application's needs
          const resultText = `Processed image of width ${width} and height ${height}.`;
          this.ocrResult = resultText;
          console.log('resultText-----> ', resultText);
        })
        .catch((error) => {
          console.error('Error reading image:', error);
          this.ocrResult = 'Error processing the image.';
        })
        .finally(() => {
          this.loading = false;
        });
    }
  }

  private parseAAMVA(data: string): void {
    const regexName = /DAC([^\n]*)/;
    const regexDOB = /DBB(\d{8})/;
    const regexLicenseNumber = /DAQ([^\n]*)/;

    const nameMatch = data.match(regexName);
    const dobMatch = data.match(regexDOB);
    const licenseNumberMatch = data.match(regexLicenseNumber);

    const name = nameMatch ? nameMatch[1].trim() : 'Not found';
    const dob = dobMatch ? dobMatch[1] : 'Not found';
    const licenseNumber = licenseNumberMatch
      ? licenseNumberMatch[1].trim()
      : 'Not found';

    this.ocrResult += `\nName: ${name}\nDOB: ${dob}\nLicense Number: ${licenseNumber}`;
  }
}
